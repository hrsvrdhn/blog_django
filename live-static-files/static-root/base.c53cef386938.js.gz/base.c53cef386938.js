function typeinsearch(s) {
	document.getElementById("fillIt").value = "tags:"+s;
	document.getElementById("SearchTag").click();
}